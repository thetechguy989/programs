from pygame import *
import pygame
init() # Initiate program // ignore

d_width = 800
d_height = 600

white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
blue = (0,0,255)
orange = (255,128,0)
arrDownImg = image.load("arrowdown.png")
def arr(x,y):
    gamedisplay.blit(arrDownImg, (x,y))
gamedisplay = display.set_mode((800,600))

x = (d_width * 0.45)
y = (d_height * 0.8)

x_change = 0
y_change = 0

display.set_caption('ArrowWASD')
clock = time.Clock()
crashed = False
print("Use the W, S, A and D keys to move the arrow.")
while not crashed:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True
        if event.type == pygame.KEYDOWN:
            if event.key == K_a:
                x_change = -50
            elif event.key == K_d:
                x_change = 50
        if event.type == KEYDOWN:
            if event.key == K_w:
                y_change = -50
            elif event.key == K_s:
                y_change = 50
        if event.type == KEYUP:
            if event.key == K_w or event.key == K_s:
                y_change = 0
        if event.type == KEYUP:
            if event.key == K_a or event.key == K_d:
                x_change = 0

        x += x_change
        y += y_change

    
    gamedisplay.fill(white)
    arr(x,y)

    display.flip()
    clock.tick(60)
pygame.quit()
quit()
# End


