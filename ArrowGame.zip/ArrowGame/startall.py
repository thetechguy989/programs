from os import system, name
def menu():
    if name == 'posix':
        system('./arrowdown.py')
        system('./arrowup.py')
    if name == 'nt':
        system('start arrowdown.py')
        system('start arrowup.py')
    else:
        print("Invalid OS. Please make sure that you have not renamed any other files.")
        menu()
menu()