import os
import pathlib
import base64
class Path(type(pathlib.Path())):
    def open(self, mode='r', buffering=-1, encoding=None, errors=None, newline=None):
        if encoding is None and 'b' not in mode:
            encoding = 'utf-8'
        return super().open(mode, buffering, encoding, errors, newline)
import hashlib
file = Path("hash.256")
passpath = Path("passwords.256")

def passexist():
    if passpath.exists():
        listing = input("Type the password you want to make an entry for. You can also put a name with the Password. ")
        with open("passwords.256", "a") as passfile:
            passfile.write(listing)
            passfile.write('\n')
        passman()
    else:
        with open("passwords.256",'w') as passfile:
            passfile.write('')
            passexist()

def passlist():
    passfile2 = open("passwords.256")
    txt = passfile2.read()
    input(txt)
    passfile2.close
    passman()
        
def removelist():
        removew = input("Which listing do you want to remove? ")
        with open("passwords.256", "r") as passfile: 
      
            # read data line by line  
            data = passfile.readlines() 
              
            # open file in write mode 
            with open("passwords.256", "w") as passfile: 
              
                for line in data : 
                      
                    # condition for data to be deleted 
                    if line.strip("\n") != removew :  
                        f.write(line)
        passman()


def passman():
    print("Welcome to CentPass!")
    arl = input("Type 'add', 'remove', 'list', or 'exit'. ")
    if arl == 'add':
        passexist()
    elif arl == 'remove':
        removelist()
    elif arl == 'list':
        passlist()
    elif arl == 'exit':
        exit()
    else:
        print("Invalid. Please try again.")
        passman()
    
if file.exists():
    def auth():
        var = input('Your previously entered password: ').encode('utf-8')
        hashed_var = hashlib.sha256(var).hexdigest()
        f = open("hash.256",'r',encoding = 'utf-8')
        orighash = f.read()
        if hashed_var == orighash:
            passman()
        else:
            print("Invalid Password.")
            auth()
    auth()

else:
    password = input('Enter a password: ').encode('utf-8')
    hashed = hashlib.sha256(password).hexdigest()
    with open("hash.256",'w',encoding = 'utf-8') as f:
        f.write(hashed)